# PrepWise AI

Capstone project using Next.js, Supabase and Groq API.
